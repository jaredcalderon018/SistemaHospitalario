#include "GestorArchivos.h"
#include "Medico.h"
#include "Enfermero.h"
#include "Administrativo.h"

#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

// Devuelve el dato propio de cada tipo (especialidad, turno o area)
static string datoEspecifico(Empleado* emp)
{
	Medico* m = dynamic_cast<Medico*>(emp);
	if (m != NULL) return m->obtenerEspecialidad();
	
	Enfermero* e = dynamic_cast<Enfermero*>(emp);
	if (e != NULL) return e->obtenerTipoTurno();
	
	Administrativo* a = dynamic_cast<Administrativo*>(emp);
	if (a != NULL) return a->obtenerAreaTrabajo();
	
	return "";
}

// Formato de cada linea:
// tipo|id|nombre|salarioBase|dato especifico|horasExtra|nocturna|guardias|deducciones
bool GestorArchivos::guardarEmpleados(Lista& lista, const string& archivo)
{
	ofstream out(archivo.c_str());
	if (!out.is_open())
		return false;
	
	out << fixed << setprecision(2);
	
	Nodo* aux = lista.obtenerCabeza();
	while (aux != NULL)
	{
		Empleado* e = aux->obtenerEmpleado();
		
		out << e->obtenerTipo() << "|"
			<< e->obtenerIdentificacion() << "|"
			<< e->obtenerNombre() << "|"
			<< e->obtenerSalarioBase() << "|"
			<< datoEspecifico(e) << "|"
			<< e->obtenerHorasExtra() << "|"
			<< e->obtenerBonificacionNocturna() << "|"
			<< e->obtenerBonificacionGuardias() << "|"
			<< e->obtenerDeducciones() << "\n";
		
		aux = aux->obtenerSiguiente();
	}
	
	out.close();
	return true;
}

int GestorArchivos::cargarEmpleados(Lista& lista, const string& archivo)
{
	ifstream in(archivo.c_str());
	if (!in.is_open())
		return -1;
	
	int cargados = 0;
	string linea;
	
	while (getline(in, linea))
	{
		if (linea.empty())
			continue;
		
		// Separar los campos por '|'
		string campos[9];
		int n = 0;
		stringstream ss(linea);
		string campo;
		while (n < 9 && getline(ss, campo, '|'))
		{
			campos[n] = campo;
			n++;
		}
		
		if (n < 9)
			continue; // linea incompleta
		
		// Evitar identificaciones repetidas
		if (lista.buscar(campos[1]) != NULL)
			continue;
		
		double salario = atof(campos[3].c_str());
		Empleado* nuevo = NULL;
		
		if (campos[0] == "Medico")
			nuevo = new Medico(campos[1], campos[2], salario, campos[4]);
		else if (campos[0] == "Enfermero")
			nuevo = new Enfermero(campos[1], campos[2], salario, campos[4]);
		else if (campos[0] == "Administrativo")
			nuevo = new Administrativo(campos[1], campos[2], salario, campos[4]);
		else
			continue; // tipo desconocido
		
		nuevo->establecerHorasExtra(atof(campos[5].c_str()));
		nuevo->establecerBonificacionNocturna(atof(campos[6].c_str()));
		nuevo->establecerBonificacionGuardias(atof(campos[7].c_str()));
		nuevo->establecerDeducciones(atof(campos[8].c_str()));
		
		lista.agregar(nuevo);
		cargados++;
	}
	
	in.close();
	return cargados;
}

string GestorArchivos::textoComprobante(Empleado* emp)
{
	string etiqueta = "Detalle";
	if (emp->obtenerTipo() == "Medico") etiqueta = "Especialidad";
	else if (emp->obtenerTipo() == "Enfermero") etiqueta = "Turno";
	else if (emp->obtenerTipo() == "Administrativo") etiqueta = "Area de trabajo";
	
	time_t ahora = time(NULL);
	char fecha[20];
	strftime(fecha, sizeof(fecha), "%d/%m/%Y", localtime(&ahora));
	
	ostringstream s;
	s << fixed << setprecision(2);
	
	s << "==========================================\n";
	s << "          COMPROBANTE DE PAGO\n";
	s << "              HOSPITAL\n";
	s << "==========================================\n";
	s << "Fecha:            " << fecha << "\n";
	s << "Identificacion:   " << emp->obtenerIdentificacion() << "\n";
	s << "Nombre:           " << emp->obtenerNombre() << "\n";
	s << "Tipo:             " << emp->obtenerTipo() << "\n";
	s << etiqueta << ": " << datoEspecifico(emp) << "\n";
	s << "------------------------------------------\n";
	s << "Salario base:             " << emp->obtenerSalarioBase() << "\n";
	s << "Horas extra:              " << emp->obtenerHorasExtra() << "\n";
	s << "Bonificacion nocturna:    " << emp->obtenerBonificacionNocturna() << "\n";
	s << "Bonificacion guardias:    " << emp->obtenerBonificacionGuardias() << "\n";
	s << "------------------------------------------\n";
	s << "Salario bruto:            " << emp->calcularSalarioBruto() << "\n";
	s << "Deducciones:              " << emp->obtenerDeducciones() << "\n";
	s << "SALARIO NETO:             " << emp->calcularSalarioNeto() << "\n";
	s << "==========================================\n";
	
	return s.str();
}

bool GestorArchivos::generarComprobante(Empleado* emp, const string& archivo)
{
	ofstream out(archivo.c_str());
	if (!out.is_open())
		return false;
	
	out << textoComprobante(emp);
	out.close();
	return true;
}
