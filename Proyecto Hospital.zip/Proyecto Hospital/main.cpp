#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>

#include "Lista.h"
#include "Medico.h"
#include "Enfermero.h"
#include "Administrativo.h"
#include "GestorArchivos.h"

using namespace std;

const string ARCHIVO_DATOS = "empleados.txt";

string leerTexto(const string& mensaje)
{
	string texto;
	do
	{
		cout << mensaje;
		getline(cin, texto);
		if (texto.empty())
			cout << "  El dato no puede estar vacio.\n";
		else if (texto.find('|') != string::npos)
		{
			cout << "  No se permite el caracter '|'.\n";
			texto = "";
		}
	} while (texto.empty() && cin.good());
	return texto;
}

double leerNumero(const string& mensaje)
{
	string linea;
	double valor;
	while (cin.good())
	{
		cout << mensaje;
		getline(cin, linea);
		istringstream ss(linea);
		char resto;
		if ((ss >> valor) && !(ss >> resto) && valor >= 0)
			return valor;
		cout << "  Ingrese un numero valido (mayor o igual a 0).\n";
	}
	return 0;
}

int leerOpcion(const string& mensaje)
{
	string linea;
	int valor;
	while (cin.good())
	{
		cout << mensaje;
		getline(cin, linea);
		istringstream ss(linea);
		char resto;
		if ((ss >> valor) && !(ss >> resto))
			return valor;
		cout << "  Opcion invalida.\n";
	}
	return 0; // si se cierra la entrada, sale del programa
}


void vaciarLista(Lista& lista)
{
	while (!lista.estaVacia())
	{
		Empleado* e = lista.obtenerCabeza()->obtenerEmpleado();
		string id = e->obtenerIdentificacion();
		lista.eliminar(id);
		delete e;
	}
}

// ---------- Opciones del menu ----------

void registrarEmpleado(Lista& lista)
{
	cout << "\n--- Registrar empleado ---\n";
	cout << "1. Medico\n2. Enfermero\n3. Administrativo\n";
	int tipo = leerOpcion("Tipo de empleado: ");
	
	if (tipo < 1 || tipo > 3)
	{
		cout << "Tipo invalido.\n";
		return;
	}
	
	string id = leerTexto("Identificacion: ");
	if (lista.buscar(id) != NULL)
	{
		cout << "Ya existe un empleado con esa identificacion.\n";
		return;
	}
	
	string nombre = leerTexto("Nombre: ");
	double salario = leerNumero("Salario base: ");
	
	Empleado* nuevo = NULL;
	
	if (tipo == 1)
		nuevo = new Medico(id, nombre, salario, leerTexto("Especialidad: "));
	else if (tipo == 2)
		nuevo = new Enfermero(id, nombre, salario, leerTexto("Turno (Diurno/Nocturno/Mixto): "));
	else
		nuevo = new Administrativo(id, nombre, salario, leerTexto("Area de trabajo: "));
	
	lista.agregar(nuevo);
	cout << "Empleado registrado correctamente.\n";
}

void listarEmpleados(Lista& lista)
{
	cout << "\n--- Lista de empleados ---\n";
	
	if (lista.estaVacia())
	{
		cout << "No hay empleados registrados.\n";
		return;
	}
	
	cout << fixed << setprecision(2);
	cout << left << setw(8) << "ID" << setw(18) << "Nombre"
		<< setw(16) << "Tipo" << setw(14) << "Bruto" << "Neto\n";
	cout << "------------------------------------------------------------\n";
	
	Nodo* aux = lista.obtenerCabeza();
	while (aux != NULL)
	{
		Empleado* e = aux->obtenerEmpleado();
		cout << left << setw(8) << e->obtenerIdentificacion()
			<< setw(18) << e->obtenerNombre()
			<< setw(16) << e->obtenerTipo()
			<< setw(14) << e->calcularSalarioBruto()
			<< e->calcularSalarioNeto() << "\n";
		aux = aux->obtenerSiguiente();
	}
}

void buscarEmpleado(Lista& lista)
{
	cout << "\n--- Buscar empleado ---\n";
	string id = leerTexto("Identificacion: ");
	
	Empleado* e = lista.buscar(id);
	if (e == NULL)
	{
		cout << "Empleado no encontrado.\n";
		return;
	}
	
	cout << "\n" << GestorArchivos::textoComprobante(e);
}

void registrarMontos(Lista& lista)
{
	cout << "\n--- Registrar montos salariales ---\n";
	string id = leerTexto("Identificacion: ");
	
	Empleado* e = lista.buscar(id);
	if (e == NULL)
	{
		cout << "Empleado no encontrado.\n";
		return;
	}
	
	cout << "Empleado: " << e->obtenerNombre() << " (" << e->obtenerTipo() << ")\n";
	e->establecerHorasExtra(leerNumero("Monto de horas extra: "));
	e->establecerBonificacionNocturna(leerNumero("Bonificacion nocturna: "));
	e->establecerBonificacionGuardias(leerNumero("Bonificacion por guardias: "));
	e->establecerDeducciones(leerNumero("Deducciones: "));
	
	cout << fixed << setprecision(2);
	cout << "Montos registrados. Salario neto: " << e->calcularSalarioNeto() << "\n";
}

void eliminarEmpleado(Lista& lista)
{
	cout << "\n--- Eliminar empleado ---\n";
	string id = leerTexto("Identificacion: ");
	
	Empleado* e = lista.buscar(id);
	if (e == NULL)
	{
		cout << "Empleado no encontrado.\n";
		return;
	}
	
	
	lista.eliminar(id);
	delete e;
	cout << "Empleado eliminado.\n";
}

void generarComprobante(Lista& lista)
{
	cout << "\n--- Comprobante de pago ---\n";
	string id = leerTexto("Identificacion: ");
	
	Empleado* e = lista.buscar(id);
	if (e == NULL)
	{
		cout << "Empleado no encontrado.\n";
		return;
	}
	
	string archivo = "comprobante_" + id + ".txt";
	
	cout << "\n" << GestorArchivos::textoComprobante(e);
	
	if (GestorArchivos::generarComprobante(e, archivo))
		cout << "Comprobante guardado en " << archivo << "\n";
	else
		cout << "No se pudo guardar el comprobante.\n";
}

void guardarDatos(Lista& lista)
{
	if (GestorArchivos::guardarEmpleados(lista, ARCHIVO_DATOS))
		cout << "Datos guardados en " << ARCHIVO_DATOS << "\n";
	else
		cout << "Error: no se pudo guardar el archivo.\n";
}

void cargarDatos(Lista& lista)
{
	// Comprobar que el archivo exista antes de vaciar la lista actual
	ifstream prueba(ARCHIVO_DATOS.c_str());
	if (!prueba.is_open())
	{
		cout << "No se encontro el archivo " << ARCHIVO_DATOS << "\n";
		return;
	}
	prueba.close();
	
	vaciarLista(lista);
	int cargados = GestorArchivos::cargarEmpleados(lista, ARCHIVO_DATOS);
	cout << "Se cargaron " << cargados << " empleado(s).\n";
}
void ejecutarPruebas()
{
	cout << "\n--- Pruebas de calculos salariales ---\n";
	
	
	Medico medico("001", "Carlos", 600000, "Cardiologia");
	Enfermero enfermero("002", "Maria", 450000, "Nocturno");
	Administrativo administrativo("003", "Jose", 400000, "Contabilidad");
	

	medico.establecerHorasExtra(40000);
	medico.establecerBonificacionNocturna(20000);
	medico.establecerBonificacionGuardias(10000);
	medico.establecerDeducciones(75000);
	
	enfermero.establecerHorasExtra(20000);
	enfermero.establecerBonificacionNocturna(30000);
	enfermero.establecerBonificacionGuardias(20000);
	enfermero.establecerDeducciones(60000);
	
	administrativo.establecerHorasExtra(10000);
	administrativo.establecerBonificacionNocturna(5000);
	administrativo.establecerBonificacionGuardias(10000);
	administrativo.establecerDeducciones(45000);
	
	
	Empleado* empleados[] = {
		&medico,
			&enfermero,
			&administrativo
	};
	
	cout << fixed << setprecision(2);
	
	for (int i = 0; i < 3; i++)
	{
		cout << "\nTipo: " << empleados[i]->obtenerTipo();
		cout << "\nSalario bruto: " << empleados[i]->calcularSalarioBruto();
		cout << "\nSalario neto: " << empleados[i]->calcularSalarioNeto();
		cout << "\n------------------------";
	}
	cout << "\n";
}
void mostrarMenu()
{
	cout << "\n========== SISTEMA DE PLANILLA - HOSPITAL ==========\n";
	cout << " 1. Registrar empleado\n";
	cout << " 2. Listar empleados\n";
	cout << " 3. Buscar empleado\n";
	cout << " 4. Registrar montos salariales\n";
	cout << " 5. Eliminar empleado\n";
	cout << " 6. Generar comprobante de pago\n";
	cout << " 7. Guardar datos en archivo\n";
	cout << " 8. Cargar datos desde archivo\n";
	cout << " 9. Ejecutar pruebas de calculos\n";
	cout << " 0. Salir\n";
	cout << "====================================================\n";
}
	
int main()
{
	Lista lista;

// Cargar datos guardados previamente (si existen)
int cargados = GestorArchivos::cargarEmpleados(lista, ARCHIVO_DATOS);
if (cargados > 0)
	cout << "Se cargaron " << cargados << " empleado(s) desde " << ARCHIVO_DATOS << ".\n";

int opcion;
do
{
	mostrarMenu();
	opcion = leerOpcion("Seleccione una opcion: ");
	
	switch (opcion)
	{
	case 1: registrarEmpleado(lista); break;
	case 2: listarEmpleados(lista); break;
	case 3: buscarEmpleado(lista); break;
	case 4: registrarMontos(lista); break;
	case 5: eliminarEmpleado(lista); break;
	case 6: generarComprobante(lista); break;
	case 7: guardarDatos(lista); break;
	case 8: cargarDatos(lista); break;
	case 9: ejecutarPruebas(); break;
	case 0:
		guardarDatos(lista); // guarda automaticamente al salir
		cout << "Hasta luego.\n";
		break;
	default:
		cout << "Opcion invalida.\n";
	}
} while (opcion != 0);

vaciarLista(lista);

	return 0;
	
}
